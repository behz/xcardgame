/** @type {import('next').NextConfig} */
const nextConfig = {
    // output: "standalone",  enable Docker support https://vercel.com/guides/does-vercel-support-docker-deployments
};

module.exports = nextConfig;
