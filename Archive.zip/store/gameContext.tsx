import React, { createContext, useContext, useReducer } from 'react';

// Define the shape of your game's state
interface GameState {
  currentCard: Card | null;
  playerHands: { [key: string]: Card[] };
  // ... other state properties
}

const initialState: GameState = {
  currentCard: null,
  playerHands: {},
  // ... other initial state
};

// Define action types
type GameAction = { type: 'PLAY_CARD'; payload: Card } | { type: 'OTHER_ACTION' };

// Reducer function
const gameReducer = (state: GameState, action: GameAction): GameState => {
  switch (action.type) {
    case 'PLAY_CARD':
      return {
        ...state,
        currentCard: action.payload,
        // ... update logic
      };
    // ... other cases
    default:
      return state;
  }
};

// Create context
const GameContext = createContext<{
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
}>({
  state: initialState,
  dispatch: () => null
});

// Context provider
type Props = {
  children?: React.ReactNode
};
export const GameProvider: React.FC<Props> = ({ children }) => {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

// Hook to use game context
export const useGameContext = () => useContext(GameContext);

interface Card {
  number: number;
  color: string;
}

export default GameContext;
