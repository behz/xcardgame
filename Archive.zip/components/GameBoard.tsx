import React from 'react';
import { useGameContext } from '../store/gameContext';

const GameBoard: React.FC = () => {
  const { state, dispatch } = useGameContext();

  const handleCardPlay = (card: Card) => {
    // Dispatch action to play card
    dispatch({ type: 'PLAY_CARD', payload: card });
  };

  // Render the current card and player hands
  return (
    <div>
      <h2>Current Card: {state.currentCard ? `${state.currentCard.color} ${state.currentCard.number}` : 'None'}</h2>
      {/* Render player hands and other game elements */}
    </div>
  );
};

interface Card {
  number: number;
  color: string;
}

export default GameBoard;
